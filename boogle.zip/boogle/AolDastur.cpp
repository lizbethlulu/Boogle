#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <ctype.h>
#include<windows.h>
#define MAGENTA "\x1b[35m"
#define RED "\033[1;31m"
#define LIGHT_BLUE "\033[1;94m"
#define RESET "\033[0m"
#define GREEN "\033[32m"
#define YELLOW "\033[33m"

int idx;
bool treePopulated = false;
struct Node{
	char slang[100];
    char meaning[100];
    struct Node *left;
    struct Node *right;
    int height;
};

Node *root = NULL;

int height(struct Node *node){
    if (node == NULL){
    	return 0;
	}else{
		return node->height;
	}
}
 
int max(int a, int b){
    return (a > b)? a : b;
}
 
Node* newNode(char slang[],char meaning[]){
    struct Node* node = (struct Node*) malloc(sizeof(struct Node));
    strcpy(node->slang,slang);
    strcpy(node->meaning,meaning);
    node->left   = NULL;
    node->right  = NULL;
    node->height = 1;
    return node;
}

Node *rightRotate(struct Node *currentNode){
    struct Node *newParent = currentNode->left;
    struct Node *subtree = newParent->right;

    newParent->right = currentNode;
    currentNode->left = subtree;

    currentNode->height = max(height(currentNode->left), height(currentNode->right)) + 1;
    newParent->height = max(height(newParent->left), height(newParent->right)) + 1;

    return newParent;
}

Node *leftRotate(struct Node *currentNode){
    struct Node *newParent = currentNode->right;
    struct Node *subtree = newParent->left;

    newParent->left = currentNode;
    currentNode->right = subtree;

    currentNode->height = max(height(currentNode->left), height(currentNode->right)) + 1;
    newParent->height = max(height(newParent->left), height(newParent->right)) + 1;

    return newParent;
}
 
int getBalance(Node *node){
    if (node == NULL){
    	return 0;
	}
	else{
		return height(node->left) - height(node->right);
	}
}
 
Node* insert(Node* node, char slang[],char meaning[]){
    if(node == NULL){
    	printf(MAGENTA "Successfully" LIGHT_BLUE " released" YELLOW " new" GREEN " slang" RED " word\n" RESET);
    	treePopulated = true;
    	return(newNode(slang,meaning));
	}
    if(strcmp(slang, node->slang) < 0){
    	node->left  = insert(node->left, slang,meaning);
	}
    else if(strcmp(slang, node->slang) > 0){
    	node->right = insert(node->right, slang,meaning);
	}
    else{
		 strcpy(node->meaning, meaning); 
		 printf(MAGENTA "Successfully" LIGHT_BLUE " updated" YELLOW " a" GREEN " slang" RED " word\n" RESET);
		 treePopulated = true;
    	 return node;
	}
       
    node->height = 1 + max(height(node->left),height(node->right));
    int balance = getBalance(node);
    if (balance > 1 && strcmp(slang, node->left->slang) < 0){
    	return rightRotate(node);	
	}    
    if (balance < -1 && strcmp(slang, node->right->slang) > 0){
    	return leftRotate(node);
	}     
    if (balance > 1 && strcmp(slang, node->left->slang) > 0){
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    if (balance < -1 && strcmp(slang, node->right->slang) < 0){
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }
    treePopulated = true;
    return node;
}

Node *searchNode(Node* root,char slang[]){
	if(root == NULL){
		return NULL;
	}else if(strcmp(slang, root->slang) < 0){
		searchNode(root->left,slang);
	}else if(strcmp(slang, root->slang) > 0){
		searchNode(root->right,slang);
	}else if(strcmp(slang, root->slang) == 0){
		return root;
	}
}

int searchTree(char slang[]){
	int par;
	Node *temp = root;
	if(temp == NULL){
		return par = 0;
	}else if(strcmp(slang, temp->slang) < 0){
		searchNode(temp->left,slang);
	}else if(strcmp(slang, temp->slang) > 0){
		searchNode(temp->right,slang);
	}else if(strcmp(slang, temp->slang) == 0){
		return par = 1;
	}
}

void viewAll(struct Node *root){
    if(root != NULL){
    	viewAll(root->left);
        printf("%d. %s\n",idx++,root->slang);
        viewAll(root->right);
    }
    return;
}

void view(struct Node *root, char prefix[]){
	int len = strlen(prefix);
    if(root != NULL){
    	view(root->left,prefix);
        if (strncmp(root->slang, prefix, len) == 0) {
            printf("%d. %s\n", idx++,root->slang);
        }
        view(root->right,prefix);
    }
    return;
}

int check(char str[]){
	int par = 1;
	int len = strlen(str);
	if(len < 2){
		return par = 0;
	}else{
		for(int i=0;i<len;i++){
			if(i < len && str[i] == ' '){
				par = 0;
				break;
			}
		}
	}
	return par;
}

int check2(char str[]){
	int count;
	int len = strlen(str);
    if (len < 3) {
        return count = 0; 
    }else{
        for(int i = 0; i < len - 1; i++){
            if(str[i] == ' ' && str[i+1] != ' '){
                count++; 
            }
        }
        if(count < 2){ 
            count = 0;
        } 
    }
    return count;
}

void Add(){
	int res, len, par;
	char slang[100] = " ",meaning[100] = " ";
    do{
    	printf(LIGHT_BLUE "Input" YELLOW " a" GREEN " new" RED " slang" LIGHT_BLUE " word" YELLOW "[must be more than one character and contains no space] : ");
		scanf("%[^\n]", slang); getchar();
		res = check(slang);
		len = strlen(slang);
	}while(len < 2 || res == 0);
	do{
		printf(LIGHT_BLUE "Input" YELLOW " a" GREEN " new" RED " slang" LIGHT_BLUE " word" GREEN " Description" YELLOW "[must be more than 2 words] : ");
		scanf("%[^\n]", meaning); getchar();
		par = check2(meaning);
	}while(par == 0);
	root = insert(root,slang,meaning);
	system("pause");
	return;
}

void printDescription(char *meaning) {
    char *ptr = meaning;

    // Check if the meaning contains any of the specified patterns
    if (strstr(ptr, "The Word") != NULL || strstr(ptr, "the word") != NULL || strstr(ptr, "THE WORD") != NULL || strstr(ptr, "The word") != NULL || strstr(ptr, "the Word") != NULL) {
        // Skip initial articles and spaces
        while (*ptr && (isspace(*ptr) || strstr(ptr, "The Word") == ptr || strstr(ptr, "the word") == ptr || strstr(ptr, "THE WORD") == ptr || strstr(ptr, "The word") ==ptr || strstr(ptr, "the Word") == ptr)) {
            // Skip the current pattern occurrence
            while (*ptr && (strncmp(ptr, "The Word", strlen("The Word")) == 0 || strncmp(ptr, "the word", strlen("the word")) == 0 || strncmp(ptr, "THE WORD", strlen("THE WORD")) == 0 || strncmp(ptr, "The word", strlen("The word")) == 0) || strncmp(ptr, "the Word", strlen("the Word")) == 0) {
                ptr += strlen("The Word"); // Skip the length of the pattern
                // Skip any remaining whitespace
                while (*ptr && isspace(*ptr)) ptr++;
            }
        }
        // Print the rest of the meaning
        if (*ptr) {
            printf(MAGENTA "Description: " LIGHT_BLUE "same" YELLOW " meaning" GREEN " as" RED " words" YELLOW " \"%s\"\n" RESET, ptr);
        } else {
            printf(MAGENTA "Description: " LIGHT_BLUE "None\n" RESET);
        }
    } else {
        // If no specified patterns found, print the entire meaning
        printf(MAGENTA "Description: " LIGHT_BLUE "same" YELLOW " meaning" GREEN " as" RED " words" YELLOW " \"%s\"\n" RESET, meaning);
    }
}


void Search(){
	int res, len;
	char slang[100], meaningCopy[100];
	do{
    	printf(LIGHT_BLUE "Input" YELLOW " a" GREEN " new" RED " slang" LIGHT_BLUE " word" YELLOW "[must be more than one character and contains no space] : ");
		scanf("%[^\n]", slang); getchar();
		res = check(slang);
		len = strlen(slang);
	}while(len < 2 || res == 0);
	Node *temp = searchNode(root,slang);
	if(temp == NULL){
		printf(RED "There's no word \"%s\" in the dictionary.\n" RESET, slang);
		system("pause");
		return;
	}else{
		char str1[100], str2[100];
		printf(LIGHT_BLUE "Slang Word :" YELLOW " %s\n",temp->slang);
		printDescription(temp->meaning);
	}
	system("pause");
	return;
}

void View(){
	idx = 1;
	char prefix[100];
	printf(LIGHT_BLUE " Input" YELLOW " the" GREEN " prefix" RED " to" LIGHT_BLUE " be" YELLOW " searched : ");
	scanf("%[^\n]", prefix); getchar();
	int res = searchTree(prefix);
	if(res == 0){
		printf(LIGHT_BLUE "There" YELLOW " is" GREEN " no " RED "word" LIGHT_BLUE "\"%s\" in" YELLOW " the" GREEN " dictionary.\n" RESET, prefix);
	}else{
		printf(LIGHT_BLUE "Words" YELLOW " starts" GREEN " with " YELLOW " \"%s\" : \n" YELLOW, prefix);
		view(root, prefix);
	}
	system("pause");
	return;
}

void full(){
	keybd_event(VK_MENU, 0x38, 0, 0); //- Menekan tombol ALT.
	keybd_event(VK_RETURN, 0x1c, 0, 0); //- Menekan tombol ENTER.
	keybd_event(VK_RETURN, 0x1c, KEYEVENTF_KEYUP, 0); //- Melepaskan tombol ENTER.
	keybd_event(VK_MENU, 0x38, KEYEVENTF_KEYUP, 0);
}

void menu(){
	int choice;
	do{
		system("cls");
		printf(LIGHT_BLUE " ___                         _          \n" );
	    printf(RED "(  _`\\                      (_ )        \n" );
	    printf(YELLOW "| (_) )   _      _      __   | |    __  \n" );
	    printf(GREEN "|  _ <' /'_`\\  /'_`\\  /'_ `\\ | |  /'__`\\ \n");
	    printf(RED "| (_) )( (_) )( (_) )( (_) | | | (  ___/\n");
	    printf(LIGHT_BLUE "(____/'`\\___/'`\\___/'`\\__  |(___)`\\____)\n");
	    printf(RED "                     ( )_) |            \n");
	    printf(YELLOW "                      \\___/'            \n");
	    printf( MAGENTA "=========" YELLOW "==========" LIGHT_BLUE"=========" GREEN "========" RED "======="RESET);
		printf("\n \n");
		printf(LIGHT_BLUE "1.Release a new slang word\n");
		printf(YELLOW "2.Search a slang word\n");
		printf(GREEN "3.View all slang word starting with a certain prefix word\n");
		printf(RED "4.View all slang words\n");
		printf(LIGHT_BLUE "5.Exit\n");
		printf(YELLOW ">> ");
		scanf("%d", &choice); getchar();
		switch(choice){
			system("cls");
			case 1:
				system("cls");
				Add();
				break;
			case 2:
				system("cls");
				Search();
				break;
			case 3:
				system("cls");
				View();
				break;
			case 4:
				idx = 1;
				system("cls");
				if(!treePopulated){
					printf(RED "There is no slang word yet in the dictionary.\n" LIGHT_BLUE);
				}else{
					printf(LIGHT_BLUE "List of all slang words in dictionary : \n" YELLOW);
					viewAll(root);
				}
				system("pause");
				break;
			case 5:
				system("cls");
				printf(LIGHT_BLUE "Thank" YELLOW " You" GREEN "..." RED "Have" LIGHT_BLUE " a" YELLOW " nice" GREEN " day" MAGENTA "!" RESET);
		}
	}while(choice != 5);
	return;
}

int main(){
	full();
	menu();
	return 0;
}
